# Screenshots

Drop your lab screenshots in this folder, then reference them in the main README like:

```markdown
![VPC and subnets](images/01-vpc-subnets.png)
```

Suggested shots to include:

1. `01-vpc-subnets.png` — the VPC network with both subnets
2. `02-firewall-rules.png` — the firewall rules list
3. `03-web-page.png` — the nginx page loading from the web-server's external IP
4. `04-private-no-ip.png` — the db-server showing no external IP
5. `05-nat-egress.png` — (optional) terminal output of `curl` from the private VM proving NAT works
